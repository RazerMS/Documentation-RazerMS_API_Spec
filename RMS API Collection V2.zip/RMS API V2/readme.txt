Steps for using RMS API template:
1. Skip to step 2 if already install Postman else you may download from below url 
Postman Download Link: https://www.postman.com/downloads/ 
2. Import environment and collection files into Postman.
3. Plug Merchant ID provided by RMS Ops team, Verify Key and Private Key obtain from RMS merchant portal into respective environment in postman.
RMS Production merchant portal: https://portal.merchant.razer.com/index.php?mod=authentication&opt=login
RMS Sandbox merchant portal: https://sandbox.merchant.razer.com/MerchantPortal/index.php?mod=authentication&opt=login 